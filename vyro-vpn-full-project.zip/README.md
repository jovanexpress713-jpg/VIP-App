# 🚀 VYRO VPN — اتصال أسرع، خصوصية أقوى

تطبيق VPN متكامل مبني باستخدام React + Vite + Tailwind CSS + TypeScript مع واجهة مستخدم عصرية باللغتين العربية والإنجليزية.

---

## 🌟 أهم المميزات (Key Features)

- **🔐 اتصال آمن ومشفّر (Bank-Grade Encryption)**: محاكاة وتفعيل تشفير AES-256 و ChaCha20 وبروتوكولات WireGuard® و OpenVPN و VYRO Turbo™.
- **🌍 خوادم عالمية متعددة (Global Servers)**: أكثر من 20 خادم عالي السرعة موزع في قارات العالم (الشرق الأوسط، أوروبا، أمريكا، آسيا) مع دعم P2P و Streaming و Double VPN.
- **⚡ فحص ومتابعة السرعة الحية (Real-time Speed Monitor & Test)**: قياس سرعة الرفع والتنزيل وحساب معدل التأخير (Ping / Latency).
- **🛡️ جدار حماية الخصوصية (Privacy Shield)**: حماية متقدمة من تسريب DNS و WebRTC وفحص تسريب البيانات وعنوان IP الحقيقي.
- **📶 حماية شبكات الواي فاي العامة (Public Wi-Fi Security)**: كشف تلقائي للشبكات غير المشفرة وتفعيل الحماية اللحظية.
- **🔄 مفتاح القفل التلقائي (Kill Switch)**: إيقاف حركة المرور فور انقطاع الاتصال لحماية الهوية.
- **📱 واجهة ثنائية اللغة وتصميم مستجيب (RTL / LTR & Dark Theme)**: مظهر تكنولوجي داكن (Dark Cyberpunk / Sleek Navy) متوافق تماماً مع جميع الشاشات والهواتف.
- **📋 سجل الاتصال الحي (Live Diagnostic Logs)**: تتبع تفاصيل الاتصال، عناوين الخوادم والمنافذ في الوقت الفعلي.

---

## 🛠️ متطلبات التشغيل (Requirements)

- **Node.js** (v18 أو أحدث)
- **npm** أو **yarn** أو **pnpm** أو **bun**

---

## 💻 طريقة التثبيت والتشغيل المحلي (Installation & Run)

```bash
# 1. تثبيت الحزم والمكتبات
npm install

# 2. تشغيل بيئة التطوير
npm run dev

# 3. بناء النسخة الإنتاجية
npm run build
```

---

## 📂 هيكل المشروع (Project Structure)

```text
├── index.html              # الصفحة الرئيسية ومدخل التطبيق
├── package.json            # المكتبات والتبعيات
├── tsconfig.json           # إعدادات TypeScript
├── vite.config.ts          # إعدادات Vite
├── metadata.json           # إعدادات وهوية التطبيق
├── src/
│   ├── main.tsx            # نقطة انطلاق React
│   ├── App.tsx             # المكون الرئيسي وإدارة الحالة
│   ├── index.css           # تنسيقات Tailwind CSS
│   ├── types.ts            # تعريف الأنواع والبيانات
│   ├── components/         # مكونات واجهة المستخدم
│   │   ├── Header.tsx
│   │   ├── MainConnectView.tsx
│   │   ├── ServerListModal.tsx
│   │   ├── SpeedTestModal.tsx
│   │   ├── PrivacyShieldView.tsx
│   │   ├── WifiProtectionCard.tsx
│   │   ├── WorldMapVisualizer.tsx
│   │   ├── SettingsModal.tsx
│   │   └── ConnectionLogsModal.tsx
│   ├── data/
│   │   └── servers.ts      # قائمة الخوادم ومواقعها ومعلوماتها
│   └── utils/
│       └── helpers.ts      # دوال مساعدة لحساب السرعة ومحاكاة الأمان
└── public/                 # الملفات العامة وأرشيف المشروع
```

---

## 📄 الترخيص (License)
Apache-2.0

/**
 * Client-side safe downloader for VYRO VPN complete project ZIP.
 * Works 100% in-browser without sending requests to external servers,
 * avoiding Cloud Run cookie blocking and third-party authentication issues on mobile.
 */
import { PROJECT_ZIP_BASE64 } from '../data/projectZipBase64';

export function downloadProjectZipClientSide(): boolean {
  try {
    const binaryString = atob(PROJECT_ZIP_BASE64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const blob = new Blob([bytes], { type: 'application/zip' });
    const fileName = 'vyro-vpn-full-project.zip';

    // Standard Blob URL download
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    link.setAttribute('target', '_self');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 15000);

    return true;
  } catch (error) {
    console.error('Blob download failed, trying data-uri fallback:', error);
    try {
      const dataUri = `data:application/zip;base64,${PROJECT_ZIP_BASE64}`;
      const link = document.createElement('a');
      link.href = dataUri;
      link.download = 'vyro-vpn-full-project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    } catch (fallbackError) {
      console.error('Data URI download failed:', fallbackError);
      return false;
    }
  }
}
